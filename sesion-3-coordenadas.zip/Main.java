import java.util.*;
import maps.coordinates;

class Main {

  public static void maps() {
    ArrayList<coordinates> lista = new ArrayList<coordinates>();

    //variables
    double Latitude, Longitude;
    int numLados;
    Scanner input = new Scanner(System.in);
    System.out.println("======================================");
    System.out.println("Ingresar numero de lados del poligono");
    System.out.println("======================================");
    numLados = input.nextInt();
    int x=0;

    while(x<numLados){
      System.out.println("Ingresar la latitud " + (x + 1));
      Latitude = input.nextDouble();
      System.out.println("Ingresar la longitud " + (x + 1));
      System.out.println("===========================");
      Longitude = input.nextDouble();
      coordinates coor = new coordinates();
      coor.lat = Latitude;
      coor.lonj = Longitude;
      lista.add(x, coor);
      x++;
    }

    System.out.println("===========================");

    System.out.println("https://www.keene.edu/campus/maps/tool/?coordinates=");
    for (int y = 0; y <= numLados; y++) {
      if (y != numLados) {
        System.out.print(lista.get(y).lat);
        System.out.print("%2C%20");
        System.out.print(lista.get(y).lonj);
        System.out.print("%0A");
      } else {
        System.out.print(lista.get(0).lat);
        System.out.print("%2C%20");
        System.out.print(lista.get(0).lonj);
      }
    }
  }

  public static void main(String[] args) {
    System.out.println("=========================================");
    System.out.println("Bienvenidos al generador de Coordenadas");
    System.out.println("=========================================\n");
    maps();
  }
}
