package maps;
  public class coordinates{
    public double lat;
    public double lonj;
  }